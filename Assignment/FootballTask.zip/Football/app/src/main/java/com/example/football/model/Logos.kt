package com.example.football.model

data class Logos(
    val dark: String,
    val light: String
)