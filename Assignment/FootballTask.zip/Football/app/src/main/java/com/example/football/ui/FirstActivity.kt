package com.example.football.ui

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.football.databinding.ActivityFirstBinding
import com.example.football.model.Data
import com.example.football.repo.FootballRepo
import com.example.football.service.FootballApi
import com.example.football.viewmodel.FootballViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class FirstActivity : AppCompatActivity() {

    private val coroutineScope = CoroutineScope(Dispatchers.Main)
    private lateinit var binding: ActivityFirstBinding
    private val footballViewModel by viewModels<FootballViewModel>()
    private var footballListAdapter: FootballListAdapter = FootballListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFirstBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setUpViewModels()
        setUpRecyclerView()
        getResult()
    }

    private fun setUpViewModels() {
        val service = FootballApi.instance
        footballViewModel.footballRepo = FootballRepo(service)
    }

    private fun setUpRecyclerView() {
        binding.footballList.apply {
            layoutManager = LinearLayoutManager(this@FirstActivity)
            adapter = footballListAdapter
        }
    }

    private fun getResult() {
        coroutineScope.launch(Dispatchers.Main) {
            val results = footballViewModel.searchForFootball()
            Log.i("RESULTS","$results")
            footballViewModel.footballList.observe(this@FirstActivity, {
                footballListAdapter.submitList(it)
            })
        }
    }
}