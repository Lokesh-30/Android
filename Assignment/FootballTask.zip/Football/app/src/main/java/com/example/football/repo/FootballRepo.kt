package com.example.football.repo

import com.example.football.model.Football
import com.example.football.service.FootballApi
import retrofit2.Response

class FootballRepo (private val footballApi: FootballApi) {
    suspend fun searchByTerm(): Response<Football> {
        return footballApi.searchFootballByTerm()
    }
}