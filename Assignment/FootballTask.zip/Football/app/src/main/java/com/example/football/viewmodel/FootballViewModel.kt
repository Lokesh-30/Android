package com.example.football.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.football.model.Data
import com.example.football.model.Football
import com.example.football.repo.FootballRepo

class FootballViewModel(application: Application): AndroidViewModel(application) {

    var footballRepo:FootballRepo? = null
    var footballList = MutableLiveData<List<Data>>()

    suspend fun searchForFootball(){
        val results = footballRepo?.searchByTerm()
        if(results !=null && results.isSuccessful){
            val football = results.body()?.data
            footballList.postValue(football ?: emptyList())
        }
    }
}