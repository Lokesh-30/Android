package com.example.football.model

data class Football(
    val `data`: List<Data>,
    val status: Boolean
)