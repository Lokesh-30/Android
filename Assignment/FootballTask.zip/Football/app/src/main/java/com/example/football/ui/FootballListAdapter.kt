package com.example.football.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.football.databinding.SingleItemBinding
import com.example.football.model.Data

class FootballListAdapter: ListAdapter<Data, FootballListAdapter.ContactViewHolder>(DiffCallback()) {
    class ContactViewHolder(binding:SingleItemBinding ) : RecyclerView.ViewHolder(binding.root) {
        val abb = binding.tvId
        val name = binding.tvTitle
        val flagImage = binding.image
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        return ContactViewHolder(SingleItemBinding.inflate(LayoutInflater.from(parent.context),parent,
            false))
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val team = getItem(position)
        holder.abb.text = team.abbr
        holder.name.text = team.name
        Glide.with(holder.flagImage.context).load(team.logos.light).into(holder.flagImage)
    }
}