package com.example.football.service

import com.example.football.model.Football
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface FootballApi {

    @GET("/leagues")
    suspend fun searchFootballByTerm(): Response<Football>

    companion object{
        val instance: FootballApi by lazy {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://api-football-standings.azharimm.site/")
                .addConverterFactory(GsonConverterFactory.create()) // Using Gson to parse JSON response
                .build()
            retrofit.create(FootballApi::class.java)
        }
    }
}